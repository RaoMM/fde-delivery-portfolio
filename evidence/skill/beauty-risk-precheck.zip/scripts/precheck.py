#!/usr/bin/env python3
"""Deterministic entry-risk precheck. See ../references/risk-policy.md."""
from __future__ import annotations
import argparse, json

RULES = (
    ("SENSITIVE_POPULATION", ("敏感", "孕", "儿童", "皮肤破损", "药物"), "涉及敏感人群或特殊使用条件，需人工确认。"),
    ("SUSPECTED_ADVERSE_REACTION", ("不良反应", "红肿", "刺痛", "瘙痒", "水疱", "眼部", "就医"), "涉及疑似不良反应，停止自动链路并交人工处理。"),
    ("COMPLEX_COMPLAINT", ("投诉", "赔偿", "媒体", "监管"), "涉及复杂客诉或外部风险，需人工确认。"),
)

def precheck(question: str) -> dict:
    if not question or not question.strip():
        raise ValueError("question must not be empty")
    reasons = [{"code": code, "matched_terms": [term for term in terms if term in question], "reason": reason}
               for code, terms, reason in RULES if any(term in question for term in terms)]
    direct = bool(reasons)
    return {"direct_human_handoff_required": direct,
            "next_step": "DIRECT_HUMAN_HANDOFF" if direct else "PROCEED_TO_RETRIEVAL",
            "reasons": reasons,
            "handoff_package": {"question": question, "reasons": reasons,
                "items_to_confirm": ["由资深员工确认处理口径"],
                "boundary": "仅供入口人工转接；不构成医疗、售后或赔偿结论。"} if direct else None}

if __name__ == "__main__":
    parser = argparse.ArgumentParser(); parser.add_argument("--question", required=True); args = parser.parse_args()
    print(json.dumps(precheck(args.question), ensure_ascii=False, indent=2))

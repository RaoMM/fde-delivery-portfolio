#!/usr/bin/env python3
from __future__ import annotations
import json
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
from precheck import precheck

def main() -> int:
    cases = json.loads((Path(__file__).parent / "cases.json").read_text())
    passed = 0
    for case in cases:
        result = precheck(case["question"])
        actual_codes = [r["code"] for r in result["reasons"]]
        ok = result["next_step"] == case["expected_next_step"] and actual_codes == case["expected_codes"]
        status = "PASS" if ok else "FAIL"
        expected_codes = ", ".join(case["expected_codes"]) or "(none)"
        actual_codes_text = ", ".join(actual_codes) or "(none)"
        print(f"{status} | {case['id']} | {case['name']}")
        print(f"  input:    {case['question']}")
        print(f"  expected: {case['expected_next_step']} | {expected_codes}")
        print(f"  actual:   {result['next_step']} | {actual_codes_text}")
        passed += int(ok)
    print(f"\n{passed}/{len(cases)} cases passed")
    return 0 if passed == len(cases) else 1

if __name__ == "__main__": raise SystemExit(main())
